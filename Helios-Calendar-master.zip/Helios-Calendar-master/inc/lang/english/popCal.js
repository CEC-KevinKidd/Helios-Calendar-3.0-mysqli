var HC_LANG_MONTHS = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
var HC_LANG_ABBRV = new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
var HC_LANG_DOW = new Array("S","M","T","W","T","F","S");
var HC_LANG_TODAY = "Today";
var HC_LANG_POPSTART = 0;		// 0 = Sunday, 6 = Saturday