<?php
$hc_lang_synd = array(

'Powered'			=>	'Powered by:',
'AllDay'			=>	'All Day',
'TBA'				=>	'TBA',
'Visit'				=>	'Visit ' . CalName,
'Website'			=>	'Website:',
'ClickToVisit'		=>	'Click to Visit',
'Phone'				=>	'Phone:',
'EventCnt'			=>	'Events:',
'Next'				=>	'Next Event:',
'NoEvents'			=>	'There are currently no events available for this list.',
);	?>