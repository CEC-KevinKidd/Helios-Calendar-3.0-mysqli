<?php
$hc_lang_rss = array(

'Upcoming'			=>	'Upcoming Events From ' . CalName,
'Custom'			=>	'Custom Events Feed - ' . CalName,
'RSSSorry'			=>	'Unavailable Feed',
'RSSNoEvents'		=>	'There are no events available for this feed.',
'RSSNoLink'			=>	'Please visit our calendar to select from available RSS feeds.',
'Location'			=>	'Location Events',
'FeedLabel0'		=>	'All Events',
'FeedLabel1'		=>	'Newest Events',
'FeedLabel2'		=>	'Most Popular Events',
'FeedLabel3'		=>	'Featured Events',
'FeedLabel4'		=>	'Most Discussed Events',
'FeedLabelCustom'	=>	'Custom Feed',
);	?>