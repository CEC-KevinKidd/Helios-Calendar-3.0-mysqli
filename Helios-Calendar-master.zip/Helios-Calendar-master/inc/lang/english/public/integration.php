<?php
$hc_lang_int = array(

'NoEvent'			=>	'There are no events available.',
'TitleRSS'			=>	'Subscribe via RSS',
'TitleiCal'			=>	'Subscribe via iCalendar',
'Browse'			=>	'All Events',
'Submit'			=>	'Submit Your Events',
'TimeTBA'			=>	'TBA',
'AllDay'			=>	'All Day',
);	?>