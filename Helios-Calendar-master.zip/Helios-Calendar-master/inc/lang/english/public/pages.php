<?php
$hc_lang_pages = array(

'AllDay'			=>	'All Day Event',
'TBA'				=>	'TBA',
'NoEvents'			=>	'No Events Available',
'NoLocations'		=>	'No Locations Available',
'NoNewsletters'		=>	'No Newsletters Available',
);	?>