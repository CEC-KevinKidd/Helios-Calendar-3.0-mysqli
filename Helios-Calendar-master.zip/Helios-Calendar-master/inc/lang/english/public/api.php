<?php
$hc_lang_api = array(

'EventReg0'			=>	'none',
'EventReg1'			=>	'rsvp',
'EventReg2'			=>	'eventbrite',
'ErrorHelpLink'		=>	'For assistance please visit the documentation available at:',
'ErrorU'			=>	'An unknown error occured. Please try again.',
'Error000'			=>	'No API Data Selected. Parameter \'data\' required.',
'Error001'			=>	'Invalid API Data Selection.',
'Error002'			=>	'Invalid username or API key.',
'Error003'			=>	'Event data currently unavailable. Please try again later.',
'Error004'			=>	'Category data currently unavailable. Please try again later.',
'Error005'			=>	'',
);	?>