<?php
/**
 * @package Helios Calendar
 * @license GNU General Public License version 2 or later; see LICENSE
 */
	if(!defined('isHC')){exit(-1);}
	
	// Development -1, Production 0
	error_reporting(0);
	
	/** MySQL Hostname. Typically localhost, however, it may vary for your environment.*/
	//session_save_path("/cgi-bin/tmp");
	define("DB_HOST", "");
	/** MySQL Database Name*/
	define("DB_NAME", "");
	/** MySQL Server Username.*/
	define("DB_USER", "");
	/** MySQL Server Password. */
	define("DB_PASS", "");
	/** MySQL Datatable Prefix. Should only be edited prior to first setup. */
	define("HC_TblPrefix", "");
	
	/** APC Cache Entry Prefix. */
	define("HC_APCPrefix", "");
		
	/** Calendar URL. */
	define("CalRoot", "");
	/** Admin Console URL */
	define("AdminRoot", "");
	/** Calendar Name */
	define("CalName", "");
	
	/**
	 * A random string used to create cookies named uniquely for your calendar.
	 * A length of at least 40 random characters is recommended. Generator available at link.
	 */
	define("HC_Rando", "");
	
	/**
	 * Access code to perform installation and upgrades.
	 */
	define("HC_Install", "");
		
	/**
	 * The following configuration options are not required for all installs. For details please visit the setup documentation.
	 */
	
	/** Enable Named Setting Variable Cache */
	//define("HC_Named", true);
	
	/** Specify Server Timezone */
	//ini_set('date.timezone','');
	
	/** Manually defined session save path. */
	//session_save_path("");
?>