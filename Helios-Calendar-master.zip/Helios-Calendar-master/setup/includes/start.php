<?php
/**
 * @package Helios Calendar
 * @license GNU General Public License version 2 or later; see LICENSE
 */
?>
		<form name="frm" id="frm" method="post" action="index.php" onsubmit="return (document.getElementById('start').value != '') ? true : false;">
		<fieldset style="border:0;margin:200px 0 10px 230px;">
			<input name="start" id="start" type="password" value="" required="required" autofocus="autofocus" />
			<input type="submit" name="begin" id="begin" value="Begin" />
		</fieldset>
		</form>