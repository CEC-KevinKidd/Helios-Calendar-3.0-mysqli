<?php
//	Helios Meta Cache - Delete this file when upgrading.

$hc_meta = array(

'1'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'2'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'submit'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'search'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'searchresult'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'signup'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'send'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'rsvp'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'tools'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'rss'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'newsletter'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'archive'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'filter'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'digest'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'signin'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
'acc'	=>	array('title' => '', 'keywords' => '', 'desc' => ''),
);
?>