<?php
/*
	Helios Cache Age File. - Delete this file when upgrading.
*/
?>