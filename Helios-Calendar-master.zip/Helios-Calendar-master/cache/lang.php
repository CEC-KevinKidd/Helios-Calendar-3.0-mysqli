<?php
//	Helios Language Pack Links Cache - Delete this file when upgrading.?>

				<a href="http://cecenergy/calendar2/lang.php?l=english" title="english" rel="nofollow"><img src="http://cecenergy/calendar2/inc/lang/english/icon.png" width="16" height="11" alt="english" /></a>