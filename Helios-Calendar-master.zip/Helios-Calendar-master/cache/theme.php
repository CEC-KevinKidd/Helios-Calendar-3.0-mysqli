<?php
//	Helios Theme Select Cache - Delete this file when upgrading.
echo '
		<select name="hc_theme" id="hc_theme" onchange="window.location.href=this.value;">
			<option'.(($_SESSION['Theme'] == 'classic') ? ' selected="selected"' : '').' value="http://cecenergy/calendar2/?theme=classic">Classic</option>
			<option'.(($_SESSION['Theme'] == 'default') ? ' selected="selected"' : '').' value="http://cecenergy/calendar2/?theme=default">Default</option>
			<option'.(($_SESSION['Theme'] == 'energy') ? ' selected="selected"' : '').' value="http://cecenergy/calendar2/?theme=energy">Energy</option>
			<option'.(($_SESSION['Theme'] == 'mobile') ? ' selected="selected"' : '').' value="http://cecenergy/calendar2/?theme=mobile">Mobile</option>
			<option'.(($_SESSION['Theme'] == 'publisher') ? ' selected="selected"' : '').' value="http://cecenergy/calendar2/?theme=publisher">Publisher</option>
		</select>';