# Helios-Calendar
#### All that great calendar taste, now with less fat.

The Helios Calendar project is a continuation of the commercial application, but released as open-source.
For more information, and to join the Helios Calendar community, please visit http://helioscalendar.org

----
## License
Helios Calendar is made available under the [GPL](http://www.gnu.org/licenses/gpl-2.0.html).

---
## Help & Documentation
- [Helios Project Forum](http://helioscalendar.org/forum)
- [Helios Calendar Documentation](http://helioscalendar.org/documentation)
